<?php include 'db.php' ;
$fname= $_POST['fname'];
$lname= $_POST['lname'];
$city= $_POST['city'];
$groupid= $_POST['groupid'];


if ($fname!="" & $lname !="" & $city!="")

{
    $sql="insert into studentsinfo (fname, lname, city, groupid)
    values('$fname', '$lname', '$city', '$groupid')";
        if($conn->query($sql) === TRUE) {
            echo "New record added";
            echo "<a href='update.php' class='top'>Home </a>";
        }

        else
        {
            echo "ERROR: " .$sql. "<br>" . $conn->error;
        }
    $conn->close(); 
}
else
    echo "None of the fields can be empty";


?>