<form name= "form1" method="post" action="create.php">
    First Name: <input type="text" name="fname"><br>
    Last Name: <input type="text" name="lname"><br>
    City: <input type="text" name="city"><br>
    Choose Group ID:
    <select name="groupid"> 
    <option value="BBCAP19"> BBCAP19 </option>
    <option value="BBCAP20"> BBCAP20 </option>
    <option value="Others"> Others </option>
</select>
<br>
<input type="submit" value="Save Data">
</form>

